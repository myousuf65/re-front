import React from 'react'
import { Button } from 'antd';
import intl from 'react-intl-universal';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';

export const ExportCSV = ({csvData, fileName}) => {

    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';

    const exportToCSV = (csvData, fileName) => {
        const ws = XLSX.utils.json_to_sheet(csvData);
        const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };
        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], {type: fileType});
        FileSaver.saveAs(data, fileName + fileExtension);
    }

    return (
        <Button onClick={() => exportToCSV(csvData,fileName)}>{intl.get('@GENERAL.EXPORT-AS-EXCEL')}</Button>
    )
}

export function ExportExampleReport (csvSummary, csvData, fileName) {

    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';
    const ws_summary = XLSX.utils.json_to_sheet(csvSummary);
    const ws_data = XLSX.utils.json_to_sheet(csvData);
    const wb = { Sheets: { 'summary': ws_summary,'data': ws_data }, SheetNames: ['summary','data'] };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], {type: fileType});
    FileSaver.saveAs(data, fileName + fileExtension);

}

export function ExportReport (csvSummary, csvData, fileName) {

    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';
    const ws_summary = XLSX.utils.json_to_sheet(csvSummary);
    const ws_keys = Object.keys(csvData);
    var ws_new = { 'summary': ws_summary };
    ws_keys.forEach((x)=>{
        console.log('ws_keys: ', x);
        let ws_new_data = XLSX.utils.json_to_sheet(csvData[x]);
        ws_new[x] = ws_new_data;
    });
    const wb = { Sheets: ws_new, SheetNames: ['summary'].concat(ws_keys) };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], {type: fileType});
    FileSaver.saveAs(data, fileName + fileExtension);

}

export function ExportReport2 (csvSummary, csvOverview, csvData, fileName) {

    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = '.xlsx';
    const ws_summary = XLSX.utils.json_to_sheet(csvSummary) ;
    const ws_overview = XLSX.utils.json_to_sheet(csvOverview) ;
    const ws_keys = Object.keys(csvData);
    var ws_new = { 'summary': ws_summary , 'overview': ws_overview };
    console.log("Export csv = "+ JSON.stringify(ws_summary));
    ws_keys.forEach((x)=>{
        console.log('ws_keys: ', x);
        let ws_new_data = XLSX.utils.json_to_sheet(csvData[x]);
        ws_new[x] = ws_new_data;
    });
    const wb = { Sheets: ws_new, SheetNames: ['summary','overview'].concat(ws_keys) };
    const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    const data = new Blob([excelBuffer], {type: fileType});
    FileSaver.saveAs(data, fileName + fileExtension);

}
